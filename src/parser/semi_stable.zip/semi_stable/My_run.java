import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.misc.Interval;
import org.antlr.v4.runtime.tree.*; 

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
//import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.*;




public class My_run {

    public static void main (String args[]){


	String oracle = "((tx(0).type = int close) and (((tx(0).fv > int 3000) and (tx(0).crcv = addr a)) or (((arg(0) = byte base64 0) and (verisig(arg(0),arg(1),addr o) and (tx(0).crcv = addr a))) or ((arg(0) = byte base64 1) and (verisig(arg(0),arg(1),addr o) and (tx(0).crcv = addr b))))))";


	String basic = "int a123fwg";
      

	stealLexer lexer = new stealLexer(CharStreams.fromString(oracle));
	//stealLexer lexer = new stealLexer(CharStreams.fromString(basic));
	CommonTokenStream tokens = new CommonTokenStream(lexer);
	stealParser parser = new stealParser(tokens);

	ParserRuleContext tree = parser.exp();
	// was: ParserRuleContext <Token> tree = parser.exp();

	// create standard walker
	ParseTreeWalker walker = new ParseTreeWalker();
	ABB__stealBaseListener extractor = new ABB__stealBaseListener();//(parser);
	walker.walk(extractor, tree);// initiate walk of tree with listener
    }
}
